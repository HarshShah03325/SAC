#! /usr/bin/env python

from __future__ import print_function
import pyzbar.pyzbar as pyzbar
import rospy
import cv2
import cv_bridge
import numpy as np
from nav_msgs.msg import Odometry
from tf import transformations
from geometry_msgs.msg import Twist
from sensor_msgs.msg import LaserScan,Image,CameraInfo


img=0
bridge = cv_bridge.CvBridge()

def image_callback(msg):
    global bridge, img, cx,isRight,isLeft
    img = bridge.imgmsg_to_cv2(msg,desired_encoding='bgr8')

def decode(im) : 
  # Find barcodes and QR codes
  decodedObjects = pyzbar.decode(im)

  # Print results
  for obj in decodedObjects:
    print('Type : ', obj.type)
    print('Data : ', obj.data,'\n')
    
  return decodedObjects


# Display barcode and QR code location  
def display(im, decodedObjects):

  # Loop over all decoded objects
  for decodedObject in decodedObjects: 
    points = decodedObject.polygon

    # If the points do not form a quad, find convex hull
    if len(points) > 4 : 
      hull = cv2.convexHull(np.array([point for point in points], dtype=np.float32))
      hull = list(map(tuple, np.squeeze(hull)))
    else : 
      hull = points;
    
    # Number of points in the convex hull
    n = len(hull)

    # Draw the convext hull
    for j in range(0,n):
      cv2.line(im, hull[j], hull[ (j+1) % n], (255,0,0), 3)

  # Display results 
  cv2.imshow("Results", im);
  cv2.waitKey(0);
    



def main():
    global img
    rospy.init_node('line_follower')
    img_sub = rospy.Subscriber('/mybot/camera/image_raw',Image,image_callback)
    cmd_vel_pub = rospy.Publisher('/cmd_vel',Twist,queue_size=1)

    #rospy.sleep(3)

    while not rospy.is_shutdown():
        video_reader()

if __name__=='__main__':
    main()